﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace exam_AXA.Models
{
    public class ExamModel1
    {
        
        public string Name { get; set; }

        public string Email { get; set; }
        public string Mobile { get; set; }
        public string PositionApplied { get; set; }
        public string Source { get; set; }
        
    }
    public class ExamModel2
    {

        public List<file_> file { get; set; }
     
    }
    public class file_ {

        public string mime { get; set; }
        public string data { get; set; }


    }
    public class ExamModel3
    {

        public DateTime ProposedDate { get; set; }
        public string ProposedTime { get; set; }
        public string Online { get; set; }
        


    }
    public class ExamModel3_
    {

        public string ProposedDate { get; set; }
        public string ProposedTime { get; set; }
        public string Online { get; set; }



    }
}