﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using exam_AXA.Models;
using Newtonsoft.Json;
using System.Text;
using System.Net;
using System.IO;



namespace exam_AXA.Controllers
{

    public class ExamController : Controller
    {
        // GET: Exam
        public ActionResult Index()
        {
            return View();
        }
        public async Task<ActionResult> exam1(List<ExamModel1> model)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            ServicePointManager.DefaultConnectionLimit = 9999;
            string apiUrl = "https://goodmorning-axa-dev.azure-api.net/register";
            var json = JsonConvert.SerializeObject(model[0]);
            
            var res = "";
            WebRequest requestPost = WebRequest.Create(apiUrl);
            requestPost.Method = "POST";
            requestPost.ContentType = "application/json";

            using(var SW= new StreamWriter(requestPost.GetRequestStream()))
            {
                SW.Write(json);
                SW.Flush();
                SW.Close();

                try
                {
                    var httpresponse = (HttpWebResponse)requestPost.GetResponse();

                    using (var SR = new StreamReader(httpresponse.GetResponseStream()))
                    {
                        res = SR.ReadToEnd();
                    }
                }
                catch(WebException ex)
                {
                    string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                }
                
            }
            return Json(JsonConvert.SerializeObject(res), JsonRequestBehavior.AllowGet);
        }

        public async Task<ActionResult> exam2()
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            ServicePointManager.DefaultConnectionLimit = 9999;
            string apiUrl = "https://goodmorning-axa-dev.azure-api.net/upload";

            string path = System.Web.HttpContext.Current.Server.MapPath("~/upload/ErineLopezCv.pdf");
            byte[] pdfBytes = System.IO.File.ReadAllBytes(path);
            string base64 = Convert.ToBase64String(pdfBytes);

            ExamModel2 model = new ExamModel2();

            model.file = new List<file_>();
           file_ mod2=new file_();
            try
            {

                mod2.mime = "application/pdf";
                mod2.data = base64.Replace("[","").Replace("]","");
                model.file.Add(mod2);
            }
           catch(Exception ex)
            {

            }


            var json = JsonConvert.SerializeObject(model);
            var res = "";
            WebRequest requestPost = WebRequest.Create(apiUrl);
            requestPost.Method = "POST";
            requestPost.ContentType = "application/json";
            requestPost.PreAuthenticate = true;
           // requestPost.Headers.Add("Authorization", "Bearer " + "7ba468d7-e4e7-43a1-b113-4e4e775bdab2");
            requestPost.Headers.Add("x-axa-api-key", "7ba468d7-e4e7-43a1-b113-4e4e775bdab2");

            using (var SW = new StreamWriter(requestPost.GetRequestStream()))
            {
                string json_ = json.Replace("[", "").Replace("]", "");
                SW.Write(json_);
                SW.Flush();
                SW.Close();

                try
                {
                    var httpresponse = (HttpWebResponse)requestPost.GetResponse();

                    using (var SR = new StreamReader(httpresponse.GetResponseStream()))
                    {
                        res = SR.ReadToEnd();
                    }
                }
                catch (WebException ex)
                {
                    string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                }

            }
            return Json(JsonConvert.SerializeObject(res), JsonRequestBehavior.AllowGet);
        }

        public async Task<ActionResult> exam3(List<ExamModel3> model)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            ServicePointManager.DefaultConnectionLimit = 9999;
            string apiUrl = "https://goodmorning-axa-dev.azure-api.net/schedule";
            var json = JsonConvert.SerializeObject(model[0]);
            ExamModel3_ mdl = new ExamModel3_();
            mdl.ProposedDate = model[0].ProposedDate.ToString("yyyy-MM-dd");
            mdl.ProposedTime = model[0].ProposedTime;
            mdl.Online = "true";
            var res = "";
            var json1 = JsonConvert.SerializeObject(mdl);
            WebRequest requestPost = WebRequest.Create(apiUrl);
            requestPost.Method = "POST";
            requestPost.ContentType = "application/json";
            requestPost.Headers.Add("x-axa-api-key", "7ba468d7-e4e7-43a1-b113-4e4e775bdab2");

            using (var SW = new StreamWriter(requestPost.GetRequestStream()))
            {
                SW.Write(json1);
                SW.Flush();
                SW.Close();

                try
                {
                    var httpresponse = (HttpWebResponse)requestPost.GetResponse();

                    using (var SR = new StreamReader(httpresponse.GetResponseStream()))
                    {
                        res = SR.ReadToEnd();
                    }
                }
                catch (WebException ex)
                {
                    string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                    return Json(JsonConvert.SerializeObject(message), JsonRequestBehavior.AllowGet);
                }

            }
            return Json(JsonConvert.SerializeObject(res), JsonRequestBehavior.AllowGet);
        }
    }
}