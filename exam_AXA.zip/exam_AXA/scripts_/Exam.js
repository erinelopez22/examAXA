﻿$(document).ready(function () {
    $("#BtnBuy1").on("click", function () {

        var i1 = $("#input1");
        var i2 = $("#input2");
        var i3 = $("#input3");
        var i4 = $("#input4");
        var i5 = $("#input5");

        var body_Model = [];
        console.log(i3.val());
        body_Model.push({
            Name: i1.val(),
            Email: i2.val(),
            Mobile: i3.val(),
            PositionApplied: i4.val(),
            Source: i5.val(),
        });
        console.log(body_Model);
        $.post("/Exam/exam1", { model: body_Model })
       .done(function (data) {
           data = JSON.parse(data);
           alert(data);

       })
       .fail(function (stat, msg, custom) {
           console.log("error");
           //toastr.warning(stat.status + ": " + custom)
       });
    });
    $("#BtnBuy2").on("click", function () {

        $.post("/Exam/exam2" )
       .done(function (data) {
           data = JSON.parse(data);
           alert(data);

       })
       .fail(function (stat, msg, custom) {
           console.log("error");

       });
    });
    $("#BtnBuy3").on("click", function () {


            var i1 = $("#input11");
            var i2 = $("#input22");


            var body_Model = [];
        
            body_Model.push({
                ProposedDate: i1.val(),
                ProposedTime: i2.val(),
                Online: 'true'
            });
            console.log(body_Model);
            $.post("/Exam/exam3", { model: body_Model })
           .done(function (data) {
               data = JSON.parse(data);
               alert(data);

           })
           .fail(function (stat, msg, custom) {
               console.log("error");
               //toastr.warning(stat.status + ": " + custom)
           });
     
    });

});